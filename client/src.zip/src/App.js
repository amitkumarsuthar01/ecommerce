import Navbaar from "./components/header/Navbaar";
import Newnav from "./components/newnav/Newnav";
import Maincomp from "./components/home/Maincomp";
import Footer from "./components/footer/Footer";
import Signup from "./components/signup_signin/SignUp";
import Sign_in from "./components/signup_signin/Sign_in";
import Cart from "./components/cart/Cart";
import Buynow from "./components/buynow/Buynow";
import "./App.css";

import { useEffect, useState } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import { Routes, Route } from "react-router-dom";

import { ToastContainer } from "react-toastify"; // ✅ import
import "react-toastify/dist/ReactToastify.css"; // ✅ import styles

function App() {
  const [data, setData] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setData(true);
    }, 2000);
  }, []);

  return (
    <>
      {data ? (
        <>
          <Navbaar />
          <Newnav />
          <Routes>
            <Route path="/" element={<Maincomp />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Sign_in />} />
            <Route path="/getproductsone/:id" element={<Cart />} />
            <Route path="/buynow" element={<Buynow />} />
          </Routes>
          <Footer />
          <ToastContainer
            position="top-center"
            autoClose={3000} // ✅ applies default to all
            hideProgressBar={false}
            newestOnTop={true}
            closeOnClick
            rtl={false}
            pauseOnFocusLoss
            draggable
            pauseOnHover
            limit={1} // ✅ optional: only 1 toast at a time
          />
          {/* ✅ added here */}
        </>
      ) : (
        <div className="circle">
          <CircularProgress />
          <h2>Loading....</h2>
        </div>
      )}
    </>
  );
}

export default App;
